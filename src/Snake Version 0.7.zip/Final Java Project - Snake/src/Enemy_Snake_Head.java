import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.geom.Ellipse2D;
import java.net.URL;

import javax.imageio.ImageIO;


public class Enemy_Snake_Head {
 
	int xPos;
	int yPos;
	int width = 16;
	int height = 16;
	String dir;
	int nextMoveTimer;
	int moveSpeedTimer;
	int bodyLengthTimer = 200;
	int bodyLength = 2;
	String img = "";
	Image sprite;
	Enemy_Snake_Body[] bodies;
	Enemy_Snake_Body[] bodies2;
	//Use bodies.length to refer to the body length
	int speedMultiplier;
	boolean abovePlayer;
	boolean belowPlayer;
	boolean rightToPlayer;
	boolean leftToPlayer;
	String dirType;
	int[] posDiffs;
	

	//default constructor
	public Enemy_Snake_Head()
	{
		xPos = 16;
		yPos = 16;
		dir = "RIGHT";
		speedMultiplier = 1;
		Enemy_Snake_Body[] bodies = new Enemy_Snake_Body[2];
		moveSpeedTimer = 200;
		nextMoveTimer = 200;
	}
	
	//specific constructor
	public Enemy_Snake_Head(int x, int y, String d, int sM, int bL, int mST)
	{
		xPos = x;
		yPos = y;
		dir = d;
		speedMultiplier = sM;
		bodies = new Enemy_Snake_Body[bL];
		moveSpeedTimer = mST;
		nextMoveTimer = mST;
	}
	
	public void increaseLength()
	{
		bodies2 = new Enemy_Snake_Body[bodies.length];
		for(int i = 0; i < bodies.length; i++)
		{
			bodies2[i] = bodies[i];
		}
		bodies = new Enemy_Snake_Body[bodies.length + 1];
		for(int i = 0; i < bodies.length; i++)
		{
			bodies[i + 1] = bodies2[i];
		}
	}
	
	public void draw( Graphics window )
	{
		// Recover Graphics2D
	    Graphics2D g2 = (Graphics2D) window;

/*		window.setColor(Color.green);
		window.fillRect(xPos, yPos, 16, 16);*/
	    
		String img = "Enemy_Snake_Head_" + dir + ".png";
		try
		{
			URL url = getClass().getResource(img);
			sprite = ImageIO.read(url);
		}
		catch(Exception e)
		{
			System.err.println(e);
		}
		
/*		System.out.println(img);*/
		
		window.drawImage(sprite, xPos, yPos, width, height, null);
	    
	}
	
	public void think(boolean horizontalAllowed, boolean verticalAllowed)
	{
		if(posDiffs[0] > posDiffs[1] && horizontalAllowed)
		{
			dirType = "HORIZONTAL";
		}
		else if(horizontalAllowed && !verticalAllowed)
		{
			dirType = "HORIZONTAL";
		}
		else if(posDiffs[1] > posDiffs[0] && verticalAllowed)
		{
			dirType = "VERTICAL";
		}
		else if(!horizontalAllowed && verticalAllowed)
		{
			dirType = "VERTICAL";
		}
		else if(posDiffs[0] == posDiffs[1] && horizontalAllowed && verticalAllowed)
		{
			if((Math.random() * 100) > 50)
			{
				dirType = "HORIZONTAL";
			}
			else
			{
				dirType = "VERTICAL";
			}
		}
		
		if(dirType.equals("HORIZONTAL"))
		{
			if(rightToPlayer)
			{
				if(dir.equals("RIGHT"))
				{
					think(false, true);	//Turning around is a crime	
				}
				else
				{
					dir = "LEFT";
				}
			}
			else if(leftToPlayer)
			{
				if(dir.equals("LEFT"))
				{
					think(false, true);	//Turning around is a crime	
				}
				else
				{
					dir = "RIGHT";
				}
			}
		}
		
		else if(dirType.equals("VERTICAL"))
		{
			if(abovePlayer)
			{
				if(dir.equals("UP"))
				{
					think(true, false); //Turning around is a crime	
				}
				else
				{
					dir = "DOWN";
				}
			}
			else if(belowPlayer)
			{
				if(dir.equals("DOWN"))
				{
					think(true, false);	//Turning around is a crime	
				}
				else
				{
					dir = "UP";
				}
			}
		}
	}
	
	public void move(){
		
		System.out.println(nextMoveTimer);
		System.out.println(moveSpeedTimer);
		
		if(nextMoveTimer <= 0)
		{
			nextMoveTimer = moveSpeedTimer;
			
			think(true, true);
			
			for(int i = 0; i < bodies.length; i++)
			{
				//Get rid of the oldest
				if(i > 0)
				{
					bodies[i - 1] = bodies[i];
				}
			}
			
			bodies[bodies.length - 1] = new Enemy_Snake_Body(xPos, yPos, (bodyLengthTimer*bodies.length)/speedMultiplier);
			
			if(dir.equals("LEFT"))
			{
				xPos = xPos - 16;
			}
			else if(dir.equals("RIGHT"))
			{
				xPos = xPos + 16;
			}
			else if(dir.equals("UP"))
			{
				yPos = yPos - 16;
			}
			else if(dir.equals("DOWN"))
			{
				yPos = yPos + 16;
			}
			
/*			System.out.println("x: " + xPos);
			System.out.println("y: " + yPos);*/
			
/*			System.out.println(dir);*/
			
		}
	}
}
