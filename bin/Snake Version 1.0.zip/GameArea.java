import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.util.Random;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class GameArea extends JPanel implements KeyListener, Runnable {

	//ADD SOUNDS, RESTART/QUIT, AND ENEMIES
	//ADD SOUND FILES: lose.wav and eat.wav
	
	private Player_1_Snake_Head[] playerz;
	private Enemy_Snake_Head[] enemiez;
	private Snake_Food[] foodz;
	String direction = "";
	private boolean[] keys;
	private int score = 0;
	private int randomWidth;
	private int randomHeight;
	private int timer = 0;
	int timeInterval = 25;
	private boolean title;
	private boolean reset;
	private boolean playerLost;
	Random random;
	private JFrame FRAME;
	private int gameWidth;
	private int gameHeight;
/*	Food[] foodzlist;*/

	public int nextInt(int range)
	{
		return (int)(Math.random()*range);
	}
	
	public int randomWidth()
	{
		return nextInt(gameWidth/16)*16;
	}
	public int randomHeight()
	{
		return nextInt(gameHeight/16)*16;
	}
	
	public void reset()
	{
		reset = false;
		
		keys = new boolean[5];
		playerLost = false;
		timer = 0;
		score = 0;
		playerz = new Player_1_Snake_Head[1];
		playerz[0] = new Player_1_Snake_Head(randomWidth(), randomHeight(), "RIGHT", 1, 2, 150);
		enemiez = new Enemy_Snake_Head[1];
		enemiez[0] = new Enemy_Snake_Head(randomWidth(), randomHeight(), "LEFT", 1, 2, 300); //1600, 160
		foodz = new Snake_Food[1];
		foodz[0] = new Snake_Food(randomWidth(), randomHeight());
		
		title = true;
		
		this.addKeyListener(this);

		setVisible(true);
	}
	
	public GameArea(JFrame f, int Width, int Height) {
/*		reset = false;
		
		keys = new boolean[5];
		
		player = new Player_1_Snake_Head(16, 16, "RIGHT", 2, 2, 200);
		enemiez = new Enemy_Snake_Head[1];
		enemiez[0] = new Enemy_Snake_Head(randomWidth(), randomHeight(), "LEFT", 1, 10, 200); //1600, 160
		foodz = new Snake_Food[1];
		foodz[0] = new Snake_Food(randomWidth(), randomHeight());
		
		title = true;
		
		this.addKeyListener(this);
		new Thread(this).start();

		setVisible(true);*/
		FRAME = f;
		gameWidth = Width - 16;
		gameHeight = Height - 32;
		
		reset();
		new Thread(this).start();

	}
	
	Clip clip;
	Clip bgSound;
	
	public void playSound(String sndFile) {
		// load sound files
		try {
			// Open an audio input stream.
			java.net.URL url = this.getClass().getClassLoader()
					.getResource(sndFile);
			AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);
			// Get a sound clip resource.
			clip = AudioSystem.getClip();
			// Open audio clip and load samples from the audio input stream.
			clip.open(audioIn);
			clip.start();

		} catch (UnsupportedAudioFileException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (LineUnavailableException e) {
			e.printStackTrace();
		}
	}
	
	
	public void music(String sndFile){
		// load sound files
				try {
					// Open an audio input stream.
					java.net.URL url = this.getClass().getClassLoader()
							.getResource(sndFile);
					AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);
					// Get a sound clip resource.
					bgSound = AudioSystem.getClip();
					// Open audio clip and load samples from the audio input stream.
					bgSound.open(audioIn);
					bgSound.loop(100);

				} catch (UnsupportedAudioFileException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (LineUnavailableException e) {
					e.printStackTrace();
				}
		}
	
	
	public void update(Graphics window) {
		paint(window);
	}

	public void paint(Graphics window) {
		
		if(title)
		{
			window.setColor(Color.blue);
			window.fillRect(0, 0, gameWidth, gameHeight);
			window.setColor(Color.white);
			Font welcome = new Font("Comic Sand MS", Font.BOLD, 96);
			window.setFont(welcome);
			String welcomeMessage = "WELCOME!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!";
			window.drawString(welcomeMessage, 50, 100);
			welcome = new Font("Comic Sans MS", Font.PLAIN, 36);
			window.setFont(welcome);
			window.drawString("SNAKEBITE! You are now a green snake trapped in a white box. You need to get the food while enemy", 50, 150);
			window.drawString("snakes try to eat you. Don't try to break out because it will never work! Good luck!", 50, 200);
			window.drawString("Use the arrow keys and ONLY the arrow keys!", 50, 250);
			window.drawString("Press backspace to flee the current round!", 50, 300);
			//window.drawString("Press backspace NOW to quit the whole game!", 50, 350);
			window.drawString("Press Shift to tunnel under and hide from enemies/food", 50, 350);
			window.drawString("Press Space to move fast across a certain number of spaces", 50, 450);
			welcome = new Font("Comic Sans MS", Font.PLAIN, 60);
			window.setFont(welcome);
			window.drawString("A minigame developed by Alex C.", 50, 500);
			window.drawString("Press RIGHT ARROW to start or you will PROBABLY die instantly!", 20, 700);
			welcome = new Font("Comic Sans MS", Font.PLAIN, 48);
			window.setFont(welcome);
			window.drawString("Don't click with the mouse because it won't work either!", 100, 800);
		}
		else if(reset)
		{
			reset();
/*			reset = false;
			
			keys = new boolean[5];
			
			//randomWidth = (int)(Math.random()*700);
			//randomHeight = (int)(Math.random()*500);
			
			
			
			player = new Player_1_Snake_Head(16, 16, "RIGHT", 2, 2, 200);
			enemiez = new Enemy_Snake_Head[1];
			enemiez[0] = new Enemy_Snake_Head(1600, 160, "LEFT", 1, 10, 200);
			
			title = true;*/
		}
		else if(playerLost)
		{
			//playSound("lose.wav");------------------------------------------------------------------------------lose.wav
			window.setColor(Color.red);
			window.fillRect(0, 0, gameWidth, gameHeight);
			window.setColor(Color.white);
			Font welcome = new Font("Comic Sand MS", Font.BOLD, 96);
			window.setFont(welcome);
			String welcomeMessage = "YOU LOST!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!";
			window.drawString(welcomeMessage, 50, 100);
			welcome = new Font("Comic Sans MS", Font.PLAIN, 36);
			window.setFont(welcome);
			window.drawString("You probably tried to bite the red snake or something. They're filled with death, so don't go biting them.", 50, 150);
			window.drawString("Or maybe you accidently bit yourself. Don't bite yourself either.", 50, 200);
			welcome = new Font("Comic Sans MS", Font.PLAIN, 48);
			window.setFont(welcome);
			window.drawString("Because you lost, you now have to close the window to restart", 100, 600);
			window.drawString("Or you can just press backspace to return to the menu", 100, 700);
		}
		else
		{	
			window.setColor(Color.WHITE);
			window.fillRect(0, 0, gameWidth, gameHeight);
			
			timer+=1;
			System.out.println(timer);
			
			for(Player_1_Snake_Head p: playerz)
			{
				p.nextMoveTimer = p.nextMoveTimer - (timeInterval*p.speedMultiplier);
				p.move();
				for(Player_1_Snake_Body b: p.bodies)
				{
					if(!(b == null))
					{
						b.draw(window);
					}
				}
				p.draw(window);
				p.canTurn = true;
			}
			
			for(Enemy_Snake_Head e: enemiez)
			{
				if(!(e == null))
				{
					if(!(playerz[0].tunnelMode.equals("TUNNELLING")))
					{
						e.posDiffs = new int[2];
						//posDiffs[0] is the horizontal distance between the approximate center of the enemy and the approximate center of the player
						e.posDiffs[0] = Math.abs((e.xPos + (e.width/2)) - (playerz[0].xPos + (playerz[0].width/2)));
						//posDiffs[1] is the vertical distance between the approximate center of the enemy and the approximate center of the player
						e.posDiffs[1] = Math.abs((e.yPos + (e.height/2)) - (playerz[0].yPos + (playerz[0].height/2)));
						e.abovePlayer = e.yPos + e.height < playerz[0].yPos;
						e.belowPlayer = e.yPos > playerz[0].yPos + playerz[0].height;
						e.rightToPlayer = e.xPos > playerz[0].xPos + playerz[0].width;
						e.leftToPlayer = e.xPos + e.width < playerz[0].xPos;
					}
					e.nextMoveTimer = e.nextMoveTimer - (timeInterval*e.speedMultiplier);
					e.move();
					
					for(Enemy_Snake_Body b: e.bodies)
					{
						if(b == null)
						{
							//Do-Nothing Null Repellent
						}
						else
						{
							b.draw(window);
						}
					}
					e.draw(window);
				}
			}
			
			for(Snake_Food f: foodz)
			{
				f.draw(window);
			}
			
			//Collision sets
			for(Player_1_Snake_Head p: playerz)
			{
				
				//Player bites wall
				if(p.xPos > gameWidth || p.xPos < 0 || p.yPos > gameHeight || p.yPos < 0)
				{
					playerLost = true;
				}
				
				for(Player_1_Snake_Body pb: p.bodies)
				{
					if(!(pb == null))
					{
						//Player bites itself
						if(p.xPos == pb.xPos && p.yPos == pb.yPos)
						{
							playerLost = true;
						}
						for(int ie = 0; ie < enemiez.length; ie++)
						{
							Enemy_Snake_Head e = enemiez[ie];
							if(!(e == null))
							{
								//Enemy-Enemy collisions
								for(int i_other_e = 0; i_other_e < enemiez.length; i_other_e++)
								{
									Enemy_Snake_Head other_e = enemiez[i_other_e];
									if(!(enemiez[i_other_e] == null) && !(enemiez[ie] == enemiez[i_other_e]))
									{
										//Enemy bites enemy (head)
										if(e.xPos == other_e.xPos && e.yPos == other_e.yPos)
										{
											enemiez[i_other_e] = null;
											System.out.println("Enemy bites other enemy (head)");
										}
										
										for(Enemy_Snake_Body other_eb: other_e.bodies)
										{
											//Enemy bites enemy (body)
											if(!(other_eb == null))
											{
												if(e.xPos == other_eb.xPos && e.yPos == other_eb.yPos)
												{
													enemiez[i_other_e] = null;
													System.out.println("Enemy bites other enemy (body)");
												}
											}
										}
									}
								}
								//End of Enemy-Enemy Collisions
								
								//Enemy bites wall (head)
								if(e.xPos > gameWidth || e.xPos < 0 || e.yPos > gameHeight || e.yPos < 0)
								{
									enemiez[ie] = null;
									System.out.println("Enemy bites wall");
								}
								
								for(Enemy_Snake_Body eb: e.bodies)
								{
									if(!(eb == null))
									{
										//Enemy bites itself (body)
										if(e.xPos == eb.xPos && e.yPos == eb.yPos)
										{
											enemiez[ie] = null;
											System.out.println("Enemy bites itself (body)");
										}
										
										//Enemy bites player (body)
										if(pb.xPos == e.xPos && pb.yPos == e.yPos && !(pb.tunnelling.equals("TUNNELLING")))
										{
											playerLost = true;
											System.out.println("Enemy bites player (body)");
										}
										
										//Player bites enemy (body)
										if(p.xPos == eb.xPos && p.yPos == eb.yPos && !(p.tunnelMode.equals("TUNNELLING")))
										{
											playerLost = true;
											System.out.println("Player bites enemy (body)");
										}
										
										//Player bites enemy (head)
										if(p.xPos == e.xPos && p.yPos == e.yPos && !(p.tunnelMode.equals("TUNNELLING")))
										{
											playerLost = true;
											System.out.println("Player bites enemy (head)");
										}
										
										for(int n = 0; n < foodz.length; n++)
										{
											Snake_Food f = foodz[n];
											if(f.xPos > gameWidth || f.xPos < 0 || f.yPos > gameHeight || f.yPos < 0)
											{
												foodz[n] = new Snake_Food(randomWidth(), randomHeight());
											}
											if(f.xPos == p.xPos && f.yPos == p.yPos && !(p.tunnelMode.equals("TUNNELLING")))
											{
												foodz[n] = new Snake_Food(randomWidth(), randomHeight());
												//playSound("eat.wav");-----------------------------------------------------------------------------------eat.wav
												p.increaseLength();
												p.tunnelTimeMax = p.tunnelTimeMax + 50;
												score = score + 1;
												Enemy_Snake_Head[] enemiez2 = new Enemy_Snake_Head[enemiez.length];
												for(int i = 0; i < enemiez.length; i++)
												{
													enemiez2[i] = enemiez[i];
												}
												enemiez = new Enemy_Snake_Head[enemiez.length + 1];
												for(int i = 0; i < enemiez2.length; i++)
												{
													enemiez[i] = enemiez2[i];
												}
												//Enemy snakes get longer and faster
												enemiez[enemiez.length-1] = new Enemy_Snake_Head(randomWidth(), randomHeight(), "DOWN", 1, score + 2, 300 - (25*score));
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
/*			System.out.println(foodz[0].xPos);
			System.out.println(foodz[0].yPos);*/
			
			
			//draw score
			window.setColor(Color.black);;
			window.drawString("Score: " + score,25,50);
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		//NO TURNING AROUND
		if(title)
		{
			title = false;
		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT && playerz[0].dir != "RIGHT" && playerz[0].canTurn) {
			for(Player_1_Snake_Body pb: playerz[0].bodies)
			{
				if(!(pb == null) && !(pb.xPos == playerz[0].xPos - 16) && !(pb.yPos == playerz[0].yPos))
				{
					playerz[0].dir = "LEFT";
					playerz[0].canTurn = false;
				}
			}
		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT && playerz[0].dir != "LEFT" && playerz[0].canTurn) {
			for(Player_1_Snake_Body pb: playerz[0].bodies)
			{
				if(!(pb == null) && !(pb.xPos == playerz[0].xPos + 16) && !(pb.yPos == playerz[0].yPos))
				{
					playerz[0].dir = "RIGHT";
					playerz[0].canTurn = false;
				}
			}
			
		}
		if (e.getKeyCode() == KeyEvent.VK_UP && playerz[0].dir != "DOWN" && playerz[0].canTurn) {
			for(Player_1_Snake_Body pb: playerz[0].bodies)
			{
				if(!(pb == null) && !(pb.xPos == playerz[0].xPos) && !(pb.yPos == playerz[0].yPos - 16))
				{
					playerz[0].dir = "UP";
					playerz[0].canTurn = false;
				}
			}
			
		}
		if (e.getKeyCode() == KeyEvent.VK_DOWN && playerz[0].dir != "UP" && playerz[0].canTurn) {

			
			for(Player_1_Snake_Body pb: playerz[0].bodies)
			{
				if(!(pb == null) && !(pb.xPos == playerz[0].xPos) && !(pb.yPos == playerz[0].yPos + 16))
				{
					playerz[0].dir = "DOWN";
					playerz[0].canTurn = false;
				}
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_BACK_SPACE)
		{
			reset = true;
		}
		if(e.getKeyCode() == KeyEvent.VK_SHIFT)
		{
			playerz[0].specialAbility("TUNNEL");
		}
		if(e.getKeyCode() == KeyEvent.VK_SPACE)
		{
			playerz[0].specialAbility("RUN");
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void run() {
		try {
			while (true) {
				Thread.currentThread().sleep(timeInterval);

				repaint();
			}
		} catch (Exception e) {
		}

	}
}
